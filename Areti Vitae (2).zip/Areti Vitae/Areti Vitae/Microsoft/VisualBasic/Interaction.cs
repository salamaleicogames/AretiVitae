﻿using System;

namespace Microsoft.VisualBasic
{
    internal class Interaction
    {
        internal static string InputBox(string v1, string v2, string v3)
        {
            throw new NotImplementedException();
        }
    }
}