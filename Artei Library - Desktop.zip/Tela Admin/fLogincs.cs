﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class fLogincs : Form
    {
        public fLogincs()
        {
            InitializeComponent();
            txtUsuario.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fLogincs_Load(object sender, EventArgs e)
        {
            
        }

        private void linkEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            fRedefinirSenha formRed = new fRedefinirSenha();
            formRed.Show();

            
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {

            if (txtUsuario.Text == null || txtUsuario.Text == "" || mtxtSenha.Text == null || mtxtSenha.Text == "")
            {
                MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}
