﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class cadUsuario : Form
    {
        public cadUsuario()
        {
            InitializeComponent();
            BackColor = System.Drawing.Color.FromArgb(12, 27, 60);
            grpUsuario.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblUsername.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblSenha.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblEmail.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblIdade.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblAlterego.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);
            lblPlano.ForeColor = System.Drawing.Color.FromArgb(130, 151, 217);

            btnCadastrar.BackColor = System.Drawing.Color.FromArgb(130, 151, 217);
            btnCadastrar.ForeColor = System.Drawing.Color.FromArgb(12, 27, 60);

            btnLimpar.BackColor = System.Drawing.Color.FromArgb(130, 151, 217);
            btnLimpar.ForeColor = System.Drawing.Color.FromArgb(12, 27, 60);
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            int idade = int.Parse(txtIdade.Text);
            string email = txtEmail.Text;
            string senha = txtSenha.Text;
            string alterego = txtAlterego.Text;
            string tree = txtTree.Text;
            int assinatura = 0;

            if(cmbPlano.SelectedIndex == 0 ) { assinatura = 0; }
            else { assinatura = 1; }

            

            try
            {
                Usuario usuario = new Usuario();

                if (usuario.cadastrarUsuario(username, idade, email, senha, alterego, tree, assinatura) == true)
                {
                    MessageBox.Show("Usuário Cadastrado com Sucesso");
                }
                else
                {
                    MessageBox.Show("Erro no cadastro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtIdade.Clear();
            txtEmail.Clear();
            txtSenha.Clear();
            txtAlterego.Clear();
            txtTree.Clear();
            cmbPlano.SelectedIndex = -1;
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void cadUsuario_Load(object sender, EventArgs e)
        {

        }
    }
}
