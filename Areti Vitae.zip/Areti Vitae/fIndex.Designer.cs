﻿namespace Tela_Admin
{
    partial class fIndex
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.usuáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarUsuáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirUsuárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirUsuárioToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.assinaturaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerenciamentoCPFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerenciamentoCNPJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConfiguracoes = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarUsuáriosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobreNósToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuáriosToolStripMenuItem,
            this.assinaturaToolStripMenuItem,
            this.menuConfiguracoes,
            this.ajudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // usuáriosToolStripMenuItem
            // 
            this.usuáriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarUsuáriosToolStripMenuItem,
            this.excluirUsuárioToolStripMenuItem,
            this.excluirUsuárioToolStripMenuItem1});
            this.usuáriosToolStripMenuItem.Name = "usuáriosToolStripMenuItem";
            this.usuáriosToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.usuáriosToolStripMenuItem.Text = "Usuários";
            // 
            // consultarUsuáriosToolStripMenuItem
            // 
            this.consultarUsuáriosToolStripMenuItem.Name = "consultarUsuáriosToolStripMenuItem";
            this.consultarUsuáriosToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.consultarUsuáriosToolStripMenuItem.Text = "Cadastrar Usuário";
            this.consultarUsuáriosToolStripMenuItem.Click += new System.EventHandler(this.consultarUsuáriosToolStripMenuItem_Click);
            // 
            // excluirUsuárioToolStripMenuItem
            // 
            this.excluirUsuárioToolStripMenuItem.Name = "excluirUsuárioToolStripMenuItem";
            this.excluirUsuárioToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.excluirUsuárioToolStripMenuItem.Text = "Consultar Usuário";
            this.excluirUsuárioToolStripMenuItem.Click += new System.EventHandler(this.excluirUsuárioToolStripMenuItem_Click);
            // 
            // excluirUsuárioToolStripMenuItem1
            // 
            this.excluirUsuárioToolStripMenuItem1.Name = "excluirUsuárioToolStripMenuItem1";
            this.excluirUsuárioToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.excluirUsuárioToolStripMenuItem1.Text = "Excluir Usuário";
            // 
            // assinaturaToolStripMenuItem
            // 
            this.assinaturaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gerenciamentoCPFToolStripMenuItem,
            this.gerenciamentoCNPJToolStripMenuItem});
            this.assinaturaToolStripMenuItem.Name = "assinaturaToolStripMenuItem";
            this.assinaturaToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.assinaturaToolStripMenuItem.Text = "Assinatura";
            // 
            // gerenciamentoCPFToolStripMenuItem
            // 
            this.gerenciamentoCPFToolStripMenuItem.Name = "gerenciamentoCPFToolStripMenuItem";
            this.gerenciamentoCPFToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.gerenciamentoCPFToolStripMenuItem.Text = "Gerenciar Assinaturas";
            // 
            // gerenciamentoCNPJToolStripMenuItem
            // 
            this.gerenciamentoCNPJToolStripMenuItem.Name = "gerenciamentoCNPJToolStripMenuItem";
            this.gerenciamentoCNPJToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.gerenciamentoCNPJToolStripMenuItem.Text = "Desativar Assinatura";
            // 
            // menuConfiguracoes
            // 
            this.menuConfiguracoes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultarUsuáriosToolStripMenuItem1});
            this.menuConfiguracoes.Name = "menuConfiguracoes";
            this.menuConfiguracoes.Size = new System.Drawing.Size(96, 20);
            this.menuConfiguracoes.Text = "Configurações";
            // 
            // consultarUsuáriosToolStripMenuItem1
            // 
            this.consultarUsuáriosToolStripMenuItem1.Name = "consultarUsuáriosToolStripMenuItem1";
            this.consultarUsuáriosToolStripMenuItem1.Size = new System.Drawing.Size(155, 22);
            this.consultarUsuáriosToolStripMenuItem1.Text = "Consultar ADM";
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sobreNósToolStripMenuItem,
            this.toolStripMenuItem1,
            this.sairToolStripMenuItem});
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.ajudaToolStripMenuItem.Text = "Ajuda";
            // 
            // sobreNósToolStripMenuItem
            // 
            this.sobreNósToolStripMenuItem.Name = "sobreNósToolStripMenuItem";
            this.sobreNósToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sobreNósToolStripMenuItem.Text = "Sobre Nós";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // fIndex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fIndex";
            this.Text = "Areti Library";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem usuáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarUsuáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirUsuárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem assinaturaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerenciamentoCPFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerenciamentoCNPJToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuConfiguracoes;
        private System.Windows.Forms.ToolStripMenuItem consultarUsuáriosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirUsuárioToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sobreNósToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
    }
}