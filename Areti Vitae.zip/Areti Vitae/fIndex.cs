﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class fIndex : Form
    {
        int tipoUsuario;
        public fIndex()
        {
            InitializeComponent();
        }

        public fIndex(int tipo)
        {
            InitializeComponent();
            tipoUsuario = tipo;

            if (tipoUsuario == 1)
            {
                menuConfiguracoes.Visible = false;
            }

        }

        private void fIndex_Load(object sender, EventArgs e)
        {

           
        }

        private void consultarUsuáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cadUsuario cadUsuario = new cadUsuario();
            cadUsuario.MdiParent = this;
            cadUsuario.Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void excluirUsuárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            consUsuario consUsuario = new consUsuario(); 
            consUsuario.MdiParent = this;
            consUsuario.Show();
        }
    }
}
