﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class excUsuario : Form
    {
        public excUsuario()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string username = txtUsername.Text;
            string email = txtEmail.Text;
            string senha = txtSenha.Text;
           

            try
            {
                Usuario usuario = new Usuario();

                if (usuario.excluirUsuario(username, email, senha) == true)
                {
                    MessageBox.Show("Usuário Excluído com Sucesso");
                }
                else
                {
                    MessageBox.Show("Erro no exclusão");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
