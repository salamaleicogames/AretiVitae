﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class consUsuario : Form
    {
        public consUsuario()
        {
            InitializeComponent();
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                try
                {
                    //DAO_Conexao.con.Open();
                    Usuario usuario = new Usuario();
                    MySqlDataReader resultado = usuario.consultarUsuario(txtUsername.Text);

                    if (resultado.Read())
                    {
                        txtIdade.Text = resultado["idade"].ToString();
                        txtEmail.Text = resultado["email"].ToString();
                        txtSenha.Text = resultado["senha"].ToString();
                        txtAlterego.Text = resultado["alter_ego"].ToString();
                        txtTree.Text = resultado["tree"].ToString();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    DAO_Conexao.con.Close();
                }
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();
            if (usuario.atualizarUsuario(txtUsername.Text, int.Parse(txtIdade.Text), txtEmail.Text, txtSenha.Text, txtAlterego.Text, txtTree.Text))
            {
                MessageBox.Show("Usuário atualizado com sucesso!");
            }
            else
            {
                MessageBox.Show("Erro ao atualizar usuário!");
            }
        }
    }
}
