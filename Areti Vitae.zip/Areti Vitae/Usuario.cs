﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tela_Admin
{
    internal class Usuario
    {
        // Declaração das variáveis//
        string username;
        int idade;
        string email, senha, alterego, tree;


        //Declaração dos métodos Get e Set dos respectivos atributos//
        public string Username
        {
            get => username; set => username = value;
        }

        public int Idade
        {
            get => idade;  set => idade = value;
        }

        public string Email
        {
            get => email; set => email = value;
        }

        public string Senha
        {
            get => senha; set => senha = value;
        }

        public string Alterego
        {
            get => alterego; set => alterego = value;
        }

        public string Tree
        {
            get => tree; set => tree = value;
        }

        //Declaração dos métodos construtores utilizados//
        public Usuario(string username, int idade, string email, string senha, string alterego, string tree)
        {
            this.username = username;
            this.idade = idade;
            this.email = email;
            this.senha = senha;
            this.alterego = alterego;
            this.tree = tree;
        }

        public Usuario(string username)
        {
            this.username = username;
        }

        public Usuario() { }



        //Métodos//

            //Cadastrar Usuário
            public bool cadastrarUsuario(string username, int idade, string email, string senha, string alterego, string tree)
            {
                bool cad = false;

                try
                {
                    DAO_Conexao.con.Open();
                    MySqlCommand inserir = new MySqlCommand("INSERT INTO AretiVitae_Usuario (username, idade, email, senha, alter_ego, tree) VALUES " + "( '" + username + "'," + idade + ", '" + email + "', '" + senha + "', '" + alterego + "', '" + tree+ "' );", DAO_Conexao.con);

                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine("INSERT INTO AretiVitae_Usuario (username, idade, email, senha, alter_ego, tree) VALUES " + "( '" + username + "', " + idade + ", '" + email + "', '" + senha + "', '" + alterego + "', '" + tree + "' );");
                    inserir.ExecuteNonQuery();
                    cad = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    DAO_Conexao.con.Close();
                }

                return cad;
            }


        //Consultar Usuário
        public MySqlDataReader consultarUsuario(string username)
        {
            MySqlDataReader resultado = null;

            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand("SELECT * FROM AretiVitae_Usuario WHERE username = '" + username + "';", DAO_Conexao.con); 

                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine(consultar.CommandText);
                consultar.ExecuteNonQuery();
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            
            return resultado;
        }



        //Atualizar Usuário
        public bool atualizarUsuario(string username, int idade, string email, string senha, string alterego, string tree)
        {
            bool resultado = false;

            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualizar = new MySqlCommand("UPDATE AretiVitae_Usuario SET idade = " +idade+ ", email = '" +email+ "', senha = " +senha+"', alter_ego = '" +alterego+"', tree = '" +tree+"' WHERE username = '" +username+"';", DAO_Conexao.con);
                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine(atualizar.CommandText);

                atualizar.ExecuteNonQuery();
                resultado = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                resultado = false;
            }

            return resultado;
        }

    }
}
