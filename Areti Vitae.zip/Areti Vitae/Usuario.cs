﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tela_Admin
{
    internal class Usuario
    {
        // Declaração das variáveis//
        string username;
        int idade;
        string email, senha, alterego, tree;
        int assinatura, ativo;


        //Declaração dos métodos Get e Set dos respectivos atributos//
        public string Username
        {
            get => username; set => username = value;
        }

        public int Idade
        {
            get => idade;  set => idade = value;
        }

        public string Email
        {
            get => email; set => email = value;
        }

        public string Senha
        {
            get => senha; set => senha = value;
        }

        public string Alterego
        {
            get => alterego; set => alterego = value;
        }

        public string Tree
        {
            get => tree; set => tree = value;
        }

        public int Assinatura
        {
            get => assinatura; set => assinatura = value;
        }

        public int Ativo
        {
            get => ativo; set => ativo = value;
        }


        //Declaração dos métodos construtores utilizados//
        public Usuario(string username, int idade, string email, string senha, string alterego, string tree, int assinatura)
        {
            this.username = username;
            this.idade = idade;
            this.email = email;
            this.senha = senha;
            this.alterego = alterego;
            this.tree = tree;
            this.Assinatura = assinatura;
            this.Ativo = ativo;
        }

        public Usuario(string username)
        {
            this.username = username;
        }

        public Usuario() { }



        //Métodos//

            //Cadastrar Usuário
            public bool cadastrarUsuario(string username, int idade, string email, string senha, string alterego, string tree, int assinatura)
            {
                bool cad = false;

                try
                {
                    DAO_Conexao.con.Open();
                    MySqlCommand inserir = new MySqlCommand("INSERT INTO AretiVitae_Usuario (username, idade, email, senha, alter_ego, tree, assinatura, ativo) VALUES " + "( '" + username + "'," + idade + ", '" + email + "', '" + senha + "', '" + alterego + "', '" + tree+ "', " +assinatura+", 1);", DAO_Conexao.con);

                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine(inserir.CommandText);
                    inserir.ExecuteNonQuery();
                    cad = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    DAO_Conexao.con.Close();
                }

                return cad;
            }


        //Consultar Usuário
        public MySqlDataReader consultarUsuario(string username)
        {
            MySqlDataReader resultado = null;

            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand("SELECT * FROM AretiVitae_Usuario WHERE username = '" + username + "';", DAO_Conexao.con); 

                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine(consultar.CommandText);
                consultar.ExecuteNonQuery();
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            return resultado;
        }



        //Atualizar Usuário
        public bool atualizarUsuario(string username, int idade, string email, string senha, string alterego, string tree)
        {
            bool resultado = false;

            try
            {
                
                DAO_Conexao.con.Open();

                string query = "UPDATE AretiVitae_Usuario SET idade = " + idade + ", email = '" + email + "', senha = '" + senha + "', alter_ego = '" + alterego + "', tree = '" + tree + "' WHERE username = '" + username + "';";

                using (MySqlCommand atualizar = new MySqlCommand(query, DAO_Conexao.con))
                {
                    Console.WriteLine("-----------------------------------------------------------------");
                    Console.WriteLine(atualizar.CommandText);

                    atualizar.ExecuteNonQuery();
                    resultado = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                resultado = false;
            }
            finally
            {
                // Garantindo que a conexão seja fechada, mesmo que ocorra uma exceção.
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                {
                    DAO_Conexao.con.Close();
                }
            }

            return resultado;
        }


    }
}
