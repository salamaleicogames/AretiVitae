﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using BCrypt.Net;
using System.Windows.Forms;

namespace AretiVitae2
{
    // <summary>
    /// Classe responsável por representar um Usuário no sistema.
    /// Também é responsável por representar os Administradores dessa aplicação
    /// Contém dados pessoais, informações de assinatura e métodos de acesso ao banco.
    /// </summary>

    /// <remarks>
    /// Esta classe também realiza operações CRUD diretamente no MySQL.
    /// </remarks>

    ///<author>João Mantz de Oliveira e Maurício Fernandes Ferreira</author>
    internal class Usuario
    {
        #region Atributos

        /// <summary>Nome de usuário</summary>
        string username;

        /// <summary>Idade do usuário</summary>
        int idade;

        /// <summary>Email do usuário</summary>
        string email;

        /// <summary>Senha do usuário</summary>
        string senha;

        /// <summary>Código da árvore</summary>
        string cod_tree;

        /// <summary>Status da assinatura</summary>
        int assinatura;

        /// <summary>Status de atividade (0 ativo / 1 inativo)</summary>
        int ativo;

        #endregion

        #region Propriedades

        /// <summary>Obtém ou define o nome do usuário</summary>
        public string Username { get => username; set => username = value; }

        /// <summary>Obtém ou define a idade do usuário</summary>
        public int Idade { get => idade; set => idade = value; }

        /// <summary>Obtém ou define o email do usuário</summary>
        public string Email { get => email; set => email = value; }

        /// <summary>Obtém ou define a senha do usuário</summary>
        public string Senha { get => senha; set => senha = value; }

        /// <summary>Obtém ou define o código da árvore</summary>
        public string Cod_tree { get => cod_tree; set => cod_tree = value; }

        /// <summary>Obtém ou define o status da assinatura</summary>
        public int Assinatura { get => assinatura; set => assinatura = value; }

        /// <summary>Obtém ou define o status de atividade</summary>
        public int Ativo { get => ativo; set => ativo = value; }

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor padrão
        /// </summary>
        public Usuario() { }

        /// <summary>
        /// Construtor completo do usuário
        /// </summary>
        /// <param name="username">Nome do usuário</param>
        /// <param name="idade">Idade</param>
        /// <param name="email">Email</param>
        /// <param name="senha">Senha</param>
        /// <param name="Cod_tree">Código da árvore (Tree)</param>
        /// <param name="assinatura">Tipo de assinatura</param>
        public Usuario(string username, int idade, string email, string senha, string Cod_tree, int assinatura)
        {
            this.username = username;
            this.idade = idade;
            this.email = email;
            this.senha = senha;
            this.Cod_tree = Cod_tree;
            this.Assinatura = assinatura;
            this.Ativo = 0;
        }

        #endregion


        /// <summary>
        /// Método de validação do CPF digitado pelo Usuário, em casos de Cadastro e/ou Atualização do mesmo.
        /// </summary>
        /// <param name="cpf">CPF informado pelo Usuário, proveniente do formulário de Cadastro ou Consulta</param>
        /// <returns> true --> CPF válido</returns>
        /// <returns> false --> CPF inválido</returns>
        private bool validarCPF(string cpf)
        {
            //Retira os espaços e caracteres adicionais
            cpf = cpf.Replace(".", "")
                     .Replace("-", "")
                     .Trim();

            //Verifica o número de digitos (CPF possui 11 digitos)
            if (cpf.Length != 11)
            {  
                return false; 
            }
               
            if (new string(cpf[0], 11) == cpf)
            {
                return false;
            }
     

            //Vetores com multiplicadores de validação para cada cada digito do documento
            int[] mult1 = { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] mult2 = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            //Acopla os primeiros 9 digitos
            string tempCpf = cpf.Substring(0, 9);
            int soma = 0;

            for (int i = 0; i < 9; i++)
            {
                soma += int.Parse(tempCpf[i].ToString()) * mult1[i];
            }
                
            int resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;

            string digito = resto.ToString();
            tempCpf += digito;

            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * mult2[i];

            resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;

            digito += resto.ToString();

            return cpf.EndsWith(digito);
        }

        /// <summary>
        /// Método de validação do Email digitado pelo Usuário, em casos de Cadastro e/ou Atualização do mesmo.
        /// </summary>
        /// <param name="cpf">CPF informado pelo Usuário, proveniente do formulário de Cadastro ou Consulta</param>
        /// <returns> true --> CPF válido</returns>
        /// <returns> false --> CPF inválido</returns>
        private bool validarEmail(string email)
        {
            try
            {
                MailAddress endereco = new MailAddress(email);
                return endereco.Address == email;
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// Método responsável por cadastrar um Usuário no Banco de Dados
        /// </summary>
        /// <param name="username">Nome do Usuário</param>
        /// <param name="idade">Idade</param>
        /// <param name="email">Email</param>
        /// <param name="senha">Senha</param>
        /// <param name="assinatura">Tipo de Assinatura</param>
        /// <param name="tipoRegistro">Tipo de Registro</param>
        /// <param name="registro">Registro</param>
        /// <returns>True se cadastrar com sucesso</returns>
        public bool cadastrarUsuario(string username, int idade, string email, string senha, int assinatura, double valorPlano, string tipoRegistro, string registro)
        {
            bool cad = false;

            //Criptografando a senha do Usuário
            string senhaHash = BCrypt.Net.BCrypt.HashPassword(senha);

            //Validação do CPF
            if (tipoRegistro == "Pessoa Física" && !validarCPF(registro))
            {
                MessageBox.Show("CPF Inválido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            //Validação do Email
            if (!validarEmail(email))
            {
                MessageBox.Show("Email Inválido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            try
            {
                DAO_Conexao.con.Open();

                MySqlCommand inserir = new MySqlCommand("INSERT INTO AretiVitae_Usuario (username, idade, email, senha, assinatura, tipoRegistro, registro, ativo) VALUES ('" + username + "', " + idade + ", '" + email + "', '" + senhaHash + "', " + assinatura + ", '" + tipoRegistro + "', '" + registro + "', 0);", DAO_Conexao.con);

                int linhasAfetadas = inserir.ExecuteNonQuery();

                if (linhasAfetadas > 0)
                {
                    cad = true;

                    long idUsuario = inserir.LastInsertedId;

                    if (assinatura > 0)
                    {
                        DateTime dataCompra = DateTime.Today;
                        DateTime dataVencimento = dataCompra.AddMonths(1);

                        MySqlCommand inserirCompra = new MySqlCommand("INSERT INTO AretiVitae_Compra (id_usuario, plano, dataCompra, dayVencimento, ativo) VALUES (@idUsuario, @plano, @dataCompra, @dayVencimento, @ativo);", DAO_Conexao.con);

                        inserirCompra.Parameters.AddWithValue("@idUsuario", idUsuario);
                        inserirCompra.Parameters.AddWithValue("@plano", assinatura);
                        inserirCompra.Parameters.AddWithValue("@dataCompra", dataCompra);
                        inserirCompra.Parameters.AddWithValue("@dayVencimento", dataVencimento);
                        inserirCompra.Parameters.AddWithValue("@valor", valorPlano);
                        inserirCompra.Parameters.AddWithValue("@ativo", 0);

                        inserirCompra.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                    DAO_Conexao.con.Close();
            }

            return cad;
        }



        /// <summary>
        /// Método responsável por Consultar um Usuário no Banco de Dados
        /// </summary>
        /// <param name="username">Nome de Usuário</param>
        /// <returns>Retorna um vetor com os dados do usuário consultado</returns>
        public MySqlDataReader consultarUsuario(string username)
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand(
                    "SELECT * FROM AretiVitae_Usuario WHERE username = '" + username + "';",
                    DAO_Conexao.con
                );
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao consultar usuário: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return resultado;
        }


        /// <summary>
        /// Método responsável por atualizar os dados de um usuário
        /// </summary>
        /// <param name="username">Nome do Usuário</param>
        /// <param name="idade">Idade</param>
        /// <param name="email">Email</param>
        /// <param name="senha">Senha</param>
        /// <param name="assinatura">Tipo da assinatura</param>
        /// <param name="tipoRegistro">Tipo de Registro</param>
        /// <param name="registro">Registro</param>
        /// <param name="ativo">Código de Ativação do usuário</param>
        /// <returns>True se a atualização for bem sucedida</returns>
        public bool atualizarUsuario(string username, int idade, string email, string senha, int assinatura, string tipoRegistro, string registro, int ativo)
        {
            bool resultado = false;

            // Validação do CPF
            if (tipoRegistro == "Pessoa Física" && !validarCPF(registro))
            {
                MessageBox.Show("CPF Inválido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Validação do Email
            if (!validarEmail(email))
            {
                MessageBox.Show("Email Inválido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            try
            {
                DAO_Conexao.con.Open();

                // Busca os dados atuais do usuário
                int assinaturaAtual = 0;
                int idUsuario = 0;

                string sqlBusca = @"SELECT id, assinatura
                            FROM AretiVitae_Usuario
                            WHERE username = @username";

                MySqlCommand cmdBusca = new MySqlCommand(sqlBusca, DAO_Conexao.con);
                cmdBusca.Parameters.AddWithValue("@username", username);

                MySqlDataReader dr = cmdBusca.ExecuteReader();

                if (dr.Read())
                {
                    idUsuario = Convert.ToInt32(dr["id"]);
                    assinaturaAtual = Convert.ToInt32(dr["assinatura"]);
                }

                dr.Close();

                // Atualiza os dados do usuário
                string sqlUpdate = @"UPDATE AretiVitae_Usuario
                             SET idade = @idade,
                                 email = @email,
                                 senha = @senha,
                                 assinatura = @assinatura,
                                 tipoRegistro = @tipoRegistro,
                                 registro = @registro,
                                 ativo = @ativo
                             WHERE username = @username";

                MySqlCommand atualizar = new MySqlCommand(sqlUpdate, DAO_Conexao.con);

                atualizar.Parameters.AddWithValue("@idade", idade);
                atualizar.Parameters.AddWithValue("@email", email);
                
                string senhaHash = BCrypt.Net.BCrypt.HashPassword(senha);

                atualizar.Parameters.AddWithValue("@senha", senhaHash);

                atualizar.Parameters.AddWithValue("@assinatura", assinatura);
                atualizar.Parameters.AddWithValue("@tipoRegistro", tipoRegistro);
                atualizar.Parameters.AddWithValue("@registro", registro);
                atualizar.Parameters.AddWithValue("@ativo", ativo);
                atualizar.Parameters.AddWithValue("@username", username);

                int linhasAfetadas = atualizar.ExecuteNonQuery();

                if (linhasAfetadas > 0)
                {
                    resultado = true;

                    // FREE -> PLANO PAGO
                    if (assinaturaAtual == 0 && assinatura > 0)
                    {
                        DateTime dataCompra = DateTime.Today;
                        DateTime dataVencimento = dataCompra.AddMonths(1);

                        // Verifica se já existe alguma compra para o usuário
                        string sqlVerificarCompra = @"
        SELECT id
        FROM AretiVitae_Compra
        WHERE id_usuario = @idUsuario
        ORDER BY id DESC
        LIMIT 1";

                        MySqlCommand cmdVerificar = new MySqlCommand(sqlVerificarCompra, DAO_Conexao.con);
                        cmdVerificar.Parameters.AddWithValue("@idUsuario", idUsuario);

                        object resultadoCompra = cmdVerificar.ExecuteScalar();

                        // Já existe compra -> reativa e atualiza
                        if (resultadoCompra != null)
                        {
                            int idCompra = Convert.ToInt32(resultadoCompra);

                            string sqlReativarCompra = @"
                            UPDATE AretiVitae_Compra
                            SET plano = @plano,
                                dataCompra = @dataCompra,
                                dayVencimento = @dataVencimento,
                                ativo = 0
                            WHERE id = @idCompra";

                            MySqlCommand cmdReativar = new MySqlCommand(sqlReativarCompra, DAO_Conexao.con);

                            cmdReativar.Parameters.AddWithValue("@plano", assinatura);
                            cmdReativar.Parameters.AddWithValue("@dataCompra", dataCompra);
                            cmdReativar.Parameters.AddWithValue("@dataVencimento", dataVencimento);
                            cmdReativar.Parameters.AddWithValue("@idCompra", idCompra);

                            cmdReativar.ExecuteNonQuery();
                        }
                        // Não existe compra -> cria uma nova
                        else
                        {
                            string sqlCompra = @"
                            INSERT INTO AretiVitae_Compra
                            (id_usuario, plano, dataCompra, dayVencimento, ativo)
                            VALUES
                            (@idUsuario, @plano, @dataCompra, @dataVencimento, 0)";

                            MySqlCommand cmdCompra = new MySqlCommand(sqlCompra, DAO_Conexao.con);

                            cmdCompra.Parameters.AddWithValue("@idUsuario", idUsuario);
                            cmdCompra.Parameters.AddWithValue("@plano", assinatura);
                            cmdCompra.Parameters.AddWithValue("@dataCompra", dataCompra);
                            cmdCompra.Parameters.AddWithValue("@dataVencimento", dataVencimento);

                            cmdCompra.ExecuteNonQuery();
                        }
                    }

                    // PLANO PAGO -> FREE
                    else if (assinaturaAtual > 0 && assinatura == 0)
                    {
                        string sqlDesativar = @"UPDATE AretiVitae_Compra
                                        SET ativo = 1
                                        WHERE id_usuario = @idUsuario
                                        AND ativo = 0";

                        MySqlCommand cmdDesativar = new MySqlCommand(sqlDesativar, DAO_Conexao.con);

                        cmdDesativar.Parameters.AddWithValue("@idUsuario", idUsuario);

                        cmdDesativar.ExecuteNonQuery();
                    }

                    // TROCA ENTRE PLANOS PAGOS
                    else if (assinaturaAtual > 0 &&
                             assinatura > 0 &&
                             assinaturaAtual != assinatura)
                    {
                        string sqlAtualizarPlano = @"UPDATE AretiVitae_Compra
                                             SET plano = @plano
                                             WHERE id_usuario = @idUsuario
                                             AND ativo = 0";

                        MySqlCommand cmdPlano = new MySqlCommand(sqlAtualizarPlano, DAO_Conexao.con);

                        cmdPlano.Parameters.AddWithValue("@plano", assinatura);
                        cmdPlano.Parameters.AddWithValue("@idUsuario", idUsuario);

                        cmdPlano.ExecuteNonQuery();
                    }

                    // Caso o usuário esteja inativo, desativa a compra também
                    if (ativo == 1)
                    {
                        string sqlInativarCompra = @"UPDATE AretiVitae_Compra
                                             SET ativo = 1
                                             WHERE id_usuario = @idUsuario";

                        MySqlCommand cmdInativar = new MySqlCommand(sqlInativarCompra, DAO_Conexao.con);
                        cmdInativar.Parameters.AddWithValue("@idUsuario", idUsuario);

                        cmdInativar.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao atualizar usuário: " + ex.Message,
                    "Atenção",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                resultado = false;
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                    DAO_Conexao.con.Close();
            }

            return resultado;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="tipo"></param>
        /// <param name="registro"></param>
        public void buscarDadosExtras(string username, out string tipo, out string registro)
        {
            tipo = "";
            registro = "";
            try
            {
                DAO_Conexao.con.Open();
                string sql = "SELECT tipoRegistro, registro FROM AretiVitae_Usuario WHERE username = '" + username + "';";
                MySqlCommand cmd = new MySqlCommand(sql, DAO_Conexao.con);
                MySqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    tipo = dr["tipoRegistro"].ToString();
                    registro = dr["registro"].ToString();
                }
                dr.Close();
            }
            catch { }
            finally { DAO_Conexao.con.Close(); }
        }

        /// <summary>
        /// Método reponsável pela desativação de um usuário
        /// </summary>
        /// <param name="username">Nome de Usuário</param>
        /// <param name="email">Email</param>
        /// <param name="senha">Senha</param>
        /// <returns>True se a exclusão for bem sucedida</returns>
        public bool excluirUsuario(string username, string email)
        {
            bool resultado = false;
            int assinatura = 0;

            try
            {
                DAO_Conexao.con.Open();

                // Desativa o usuário
                string query = @"UPDATE AretiVitae_Usuario
                         SET ativo = 1
                         WHERE username = @username
                         AND email = @email";

                MySqlCommand atualizar = new MySqlCommand(query, DAO_Conexao.con);

                atualizar.Parameters.AddWithValue("@username", username);
                atualizar.Parameters.AddWithValue("@email", email);


                int linhasAfetadas = atualizar.ExecuteNonQuery();

                if (linhasAfetadas == 0)
                {
                    MessageBox.Show( "Usuário não encontrado ou dados inválidos.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return false;
                }

                resultado = true;

                // Obtém o ID do usuário
                string queryId = @"SELECT id
                           FROM AretiVitae_Usuario
                           WHERE username = @username";

                string queryAssinatura = @"SELECT assinatura FROM AretiVitae_Usuario WHERE username = @username";


                MySqlCommand cmdId = new MySqlCommand(queryId, DAO_Conexao.con);
                cmdId.Parameters.AddWithValue("@username", username);

                MySqlCommand cmdAssinatura = new MySqlCommand(queryAssinatura, DAO_Conexao.con);
                cmdAssinatura.Parameters.AddWithValue("@username", username);


                object result = cmdId.ExecuteScalar();
                object resultPlano = cmdAssinatura.ExecuteScalar();

                if (result != null)
                {
                    int idUsuario = Convert.ToInt32(result);
                    assinatura = Convert.ToInt32(resultPlano);

                    if(assinatura != 0)
                    {
                        string queryDesativarCompra = @"UPDATE AretiVitae_Compra
                         SET ativo = 1
                         WHERE id_usuario = @id_usuario
                         AND plano = @plano";

                        MySqlCommand cmdDesativarCompra = new MySqlCommand(queryDesativarCompra, DAO_Conexao.con);
                        cmdDesativarCompra.Parameters.AddWithValue("@id_usuario", idUsuario);
                        cmdDesativarCompra.Parameters.AddWithValue("@plano", assinatura);

                        cmdDesativarCompra.ExecuteNonQuery();
                    }
                    
                }
                else
                {
                    MessageBox.Show(
                        "Não foi possível localizar o ID do usuário.",
                        "Atenção",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);

                    resultado = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao excluir usuário: " + ex.Message,
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                resultado = false;
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                {
                    DAO_Conexao.con.Close();
                }
            }

            return resultado;
        }


        /// <summary>
        /// Retorna todos os administradores cadastrados
        /// </summary>
        public MySqlDataReader consultarUsuarioADM()
        {
            MySqlDataReader resultado = null;

            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand("SELECT * FROM AretiVitae_Admin;", DAO_Conexao.con);
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return resultado;
        }


        /// <summary>
        /// Atualiza a senha de um administrador 
        /// </summary>
        /// <param name="usuario">Nome do Usuário</param>
        /// <param name="senha">Senha</param>
        /// <returns>True se a atualização for bem sucedida</returns>
        public bool atualizarUsuarioADM(string usuario, string senha)
        {
           // string senhaHash = BCrypt.Net.BCrypt.HashPassword(senha);

            bool resultado = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualizar = new MySqlCommand("UPDATE AretiVitae_Admin SET senha = '" + senha + "' WHERE usuario = '" + usuario + "';", DAO_Conexao.con);
                int linhas = atualizar.ExecuteNonQuery();
                resultado = linhas > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                resultado = false;
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return resultado;
        }


        /// <summary>
        /// Consulta a senha do Administrador
        /// </summary>
        /// <param name="usuario">Nome do Usuário</param>
        /// <returns>Retorna a senha do Administrador</returns>
        public string consultarSenhaADM(string usuario)
        {
            string senha = "";
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand(
                    "SELECT senha FROM AretiVitae_Admin WHERE usuario = '" + usuario + "';",
                    DAO_Conexao.con
                );
                MySqlDataReader r = consultar.ExecuteReader();
                if (r.Read())
                {
                    senha = r["senha"].ToString();
                }
                r.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return senha;
        }
    }
}
