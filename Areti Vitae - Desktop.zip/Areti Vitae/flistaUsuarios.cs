﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TELA DE LISTAGEM E GERENCIAMENTO DOS USUÁRIOS
namespace Tela_Admin
{
    public partial class flistaUsuarios : Form
    {
        public flistaUsuarios()
        {
            InitializeComponent();

            //Estilização de Background
            BackColor = System.Drawing.Color.FromArgb(12, 27, 60);

            //Estilização dos Componentes
            lblTitulo.ForeColor = System.Drawing.Color.White;
            lblLegenda.ForeColor = System.Drawing.Color.White;
            lblLegAssinatura.ForeColor = System.Drawing.Color.Wheat;
            lblLegAtivo.ForeColor = System.Drawing.Color.Wheat;
        }

        
        private void listaUsuarios_Load(object sender, EventArgs e)
        {
            CarregarUsuarios(); //Chamada de método de abertura da listagem de Usuários (DatagGridView)
        }

        //Método de abertura da listagem de Usuários(DatagGridView)
        private void CarregarUsuarios()
        {
            try
            {
                // Abertura de Conexão com o BD
                if (DAO_Conexao.con.State != System.Data.ConnectionState.Open)
                {
                    DAO_Conexao.con.Open();
                }

                string query = "SELECT * FROM AretiVitae_Usuario"; // Query de consulta no Banco de Dados
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, DAO_Conexao.con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgwUsuarios.DataSource = dt; // Preenchimento do DataGridView


                //Renomeando títulos das colunas
                dgwUsuarios.Columns["id"].HeaderText = "ID";
                dgwUsuarios.Columns["username"].HeaderText = "Username";
                dgwUsuarios.Columns["idade"].HeaderText = "Idade";
                dgwUsuarios.Columns["email"].HeaderText = "E-mail";
                dgwUsuarios.Columns["senha"].HeaderText = "Senha";
                dgwUsuarios.Columns["alter_ego"].HeaderText = "Alter Ego";
                dgwUsuarios.Columns["tree"].HeaderText = "Tree (Árvore)";
                dgwUsuarios.Columns["assinatura"].HeaderText = "Assinatura";

                //Estilização das colunas do DataGridView
                dgwUsuarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgwUsuarios.ColumnHeadersDefaultCellStyle.Font = new Font("Josefin Sans", 10, FontStyle.Bold);
                dgwUsuarios.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(130, 151, 217);
                dgwUsuarios.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                dgwUsuarios.EnableHeadersVisualStyles = false;
                dgwUsuarios.DefaultCellStyle.BackColor = Color.White;
                dgwUsuarios.DefaultCellStyle.ForeColor = Color.Black;
                dgwUsuarios.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(230, 235, 250);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar usuários: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
