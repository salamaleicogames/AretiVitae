﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TELA DE GERENCIAMENTO DE USUÁRIOS QUE POSSUEM A ASSINATURA PAGA DA PLATAFORMA (NETWORK)
namespace Tela_Admin
{
    public partial class fGerenciarAssinatura : Form
    {
        public fGerenciarAssinatura()
        {
            InitializeComponent();
         
            //Chamada de método de carregamento da Lista de Usuários - com filtragem de assinatura NETWORK
            carregarUsuarios();

            //Estilização de Componentes
            BackColor = System.Drawing.Color.FromArgb(12, 27, 60);
            lblTitulo.ForeColor = System.Drawing.Color.White;
            lblLegenda.ForeColor = System.Drawing.Color.White;
            lblLegAtivo.ForeColor = System.Drawing.Color.Wheat;
        }

        private void fGerenciarAssinatura_Load(object sender, EventArgs e)
        {
        }

        //Método de carregamento da Lista de Usuários - com filtragem de assinatura NETWORK
        private void carregarUsuarios()
        {
            try
            {
                // Abertura de Conexão com o Banco de Dados
                if (DAO_Conexao.con.State != System.Data.ConnectionState.Open)
                {
                    DAO_Conexao.con.Open();
                }

                //Query para consulta no B.D - Filtragem de assinatura NETWORK
                string query = "SELECT id, username, idade, email, senha, alter_ego, tree, ativo FROM AretiVitae_Usuario WHERE assinatura = 1"; // Busca na tabela de Usuários
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, DAO_Conexao.con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgwAssinatura.DataSource = dt; // Preenchimento do DataGridView


                //Renomeando títulos das colunas
                dgwAssinatura.Columns["id"].HeaderText = "ID";
                dgwAssinatura.Columns["username"].HeaderText = "Username";
                dgwAssinatura.Columns["idade"].HeaderText = "Idade";
                dgwAssinatura.Columns["email"].HeaderText = "E-mail";
                dgwAssinatura.Columns["senha"].HeaderText = "Senha";
                dgwAssinatura.Columns["alter_ego"].HeaderText = "Alter Ego";
                dgwAssinatura.Columns["tree"].HeaderText = "Tree (Árvore)";

                //Estilização do DataGridView
                dgwAssinatura.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgwAssinatura.ColumnHeadersDefaultCellStyle.Font = new Font("Josefin Sans", 10, FontStyle.Bold);
                dgwAssinatura.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(130, 151, 217);
                dgwAssinatura.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                dgwAssinatura.EnableHeadersVisualStyles = false;
                dgwAssinatura.DefaultCellStyle.BackColor = Color.White;
                dgwAssinatura.DefaultCellStyle.ForeColor = Color.Black;
                dgwAssinatura.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(230, 235, 250);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar usuários: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
        }
    }
}
