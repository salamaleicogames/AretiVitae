﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//MENU PRINCIPAL DA FERRAMENTA 'ARETI VITAE'
namespace Tela_Admin
{
    public partial class fIndex : Form
    {
        int tipoUsuario;

    public fIndex()
        {
            InitializeComponent();
        }

        public fIndex(int tipo)
        {
            //VALIDAÇÃO DE LOGIN (ADM E ADM MASTER)
            InitializeComponent();
            tipoUsuario = tipo;

            
            if (tipoUsuario == 1) //Caso não seja ADM Master, ocultar botão de chamada da 'Área do Admnistador' 
            {
                menuConfiguracoes.Visible = false;
            }
        }

        //ABERTURA DE FORMULÁRIO DE CADASTRO/CONSULTA DE USUÁRIOS
        private void consultarUsuáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cadUsuario cadUsuario = new cadUsuario();
            cadUsuario.Show();
        }

        //OPÇÃO DE SAIR TOTALMENTE A APLICAÇÃO
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //ABERTURA DE FORMULÁRIO DE EXCLUSÃO DE USUÁRIOS
        private void excluirUsuárioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            excUsuario excUsuario = new excUsuario();
            excUsuario.Show();
        }

        //ABERTURA DE TELA DE CRÉDITOS GERAIS DA APLICAÇÃO
        private void sobreNósToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ajuda ajuda = new Ajuda();
            ajuda.ShowDialog();
        }

        //ABERTURA DE FORMULÁRIO DE GERENCIAMENTO DE ASSINATURAS
        private void gerenciarAssinaturas_Click(object sender, EventArgs e)
        {
            fGerenciarAssinatura fGerenciarAssinatura = new fGerenciarAssinatura();
            fGerenciarAssinatura.Show();
        }

        //ABERTURA DE LISTAGEM DE TODOS OS USUÁRIOS NO PRÓRPIO MENU
        private void listarUsuáriosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            flistaUsuarios listaUsuarios = new flistaUsuarios();
            listaUsuarios.MdiParent = this;
            listaUsuarios.Show();
        }

        //ABERTURA DE ÁREA DO ADMINISTRADOR
        private void consultarUsuáriosToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            fAreaADM fConsultaADM = new fAreaADM();
            fConsultaADM.ShowDialog();
        }

        private void fIndex_Load_1(object sender, EventArgs e)
        {

        }
    }

}
