﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

//TELA DE CADASTRO, CONSULTA E ATUALIZAÇÃO DE USUÁRIOS
namespace Tela_Admin
{
    public partial class cadUsuario : Form
    {
        public cadUsuario()
        {
            InitializeComponent();

            // Estilização dos componentes
            BackColor = Color.FromArgb(12, 27, 60);
            grpUsuario.ForeColor = Color.White;
            lblUsername.ForeColor = Color.White;
            lblSenha.ForeColor = Color.White;
            lblEmail.ForeColor = Color.White;
            lblIdade.ForeColor = Color.White;
            lblAlterego.ForeColor = Color.White;
            lblPlano.ForeColor = Color.White;
            lblDescricao.ForeColor = Color.White;
            lblDescricao2.ForeColor = Color.White;

            // Estilização dos botões
            btnListarUsuarios.BackColor = Color.FromArgb(130, 151, 217);
            btnListarUsuarios.ForeColor = Color.FromArgb(12, 27, 60);
            btnCadastrar.BackColor = Color.FromArgb(130, 151, 217);
            btnCadastrar.ForeColor = Color.FromArgb(12, 27, 60);
            btnAtualizar.BackColor = Color.FromArgb(130, 151, 217);
            btnAtualizar.ForeColor = Color.FromArgb(12, 27, 60);
            btnLimpar.BackColor = Color.FromArgb(130, 151, 217);
            btnLimpar.ForeColor = Color.FromArgb(12, 27, 60);

            // Configurações iniciais
            chkAtivo.Checked = true; // Por padrão, o usuário começa ativo
            cmbTipoRegistro.SelectedIndex = 0; // O tipo de Registro padrão será: Pessoa Física
        }



        // BOTÃO CADASTRAR
        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            // Atribuição dos dados dos componentes às variáveis locais
            string username = txtUsername.Text;

            // Validação do campo idade para evitar FormatException
            int idade;
            if (!int.TryParse(txtIdade.Text, out idade))
            {
                MessageBox.Show("Informe uma idade válida!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtIdade.Focus();
                return; // interrompe o cadastro se idade inválida
            }

            string email = txtEmail.Text;
            string senha = txtSenha.Text;
            string tipoPlano = cmbPlano.Text;
            string alterego = txtAlterego.Text;
            string tree = txtTree.Text;
            int assinatura = 0;
            string tipoRegistro = " ";
            string registro = " ";
            int ativo = 0;

            // Verifica qual plano foi selecionado (Free ou Premium)
            if (cmbPlano.SelectedIndex == 0) // Plano Free
            {
                assinatura = 0;
                tipoRegistro = cmbTipoRegistro.Text;
                registro = txtRegistro.Text;
            }
            else if (cmbPlano.SelectedIndex == 1) // Plano Premium
            {
                assinatura = 1;
                tipoRegistro = cmbTipoRegistro.Text;
                registro = txtRegistro.Text;
            }

            // Define o valor do campo "ativo"
           if(chkAtivo.Checked == true)
            {
                ativo = 0; //Usuário Ativo
            }
           else if(chkAtivo.Checked == false)
            {
                ativo = 1; //Usuário Inativo
            }

            //Verificação de campos vazios
            if (cmbPlano.SelectedIndex == 1) // Validação de campos vazios específica caso o Usuário escolha o Plano Network, que exige mais campos
            {
                if (username == "" || email == "" || senha == "" || alterego == "" || tree == "" || cmbPlano.SelectedIndex == -1 || cmbTipoRegistro.SelectedIndex == -1 || registro == "")
                {
                    MessageBox.Show("Preencha todos os campos corretamente!");
                    return;
                }
                else if (idade < 13)
                {
                    MessageBox.Show("Idade Mínima: 13 anos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (cmbPlano.SelectedIndex == 0) // Plano Free
            {
                if (username == "" || idade < 13 || email == "" || senha == "" || alterego == "" || tree == "")
                {
                    MessageBox.Show("Preencha todos os campos corretamente!");
                    return;
                }
                else if (idade < 13)
                {
                    MessageBox.Show("Idade Mínima: 13 anos", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

            //Envio de Dados para o B.D
            try
            {
                Usuario usuario = new Usuario();
                if (usuario.cadastrarUsuario(username, idade, email, senha, alterego, tree, assinatura, tipoRegistro, registro) == true)
                {
                    MessageBox.Show("Usuário cadastrado com sucesso!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
        }




        
        // BOTÃO ATUALIZAR
        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            // Atribuição dos dados do formulário às variáveis
            string username = txtUsername.Text;
            int idade = int.Parse(txtIdade.Text);
            string email = txtEmail.Text;
            string senha = txtSenha.Text;
            string tipoPlano = cmbPlano.Text;
            string tipoRegistro = " ";
            string registro = " ";
            string alterego = txtAlterego.Text;
            string tree = txtTree.Text;
            int assinatura = 0;
            int ativo = 0;

            // Verifica o tipo de plano
            if (cmbPlano.SelectedIndex == 0)
            {
                assinatura = 0;
            }
            else if (cmbPlano.SelectedIndex == 1)
            {
                assinatura = 1;
                tipoRegistro = cmbTipoRegistro.Text;
                registro = txtRegistro.Text;
            }

            // Marca se o usuário está ativo ou não
            ativo = chkAtivo.Checked ? 0 : 1;

            try
            {
                Usuario usuario = new Usuario();

                // Chama o método atualizarUsuario
                if (usuario.atualizarUsuario(username, idade, email, senha, alterego, tree, assinatura, tipoRegistro, registro, ativo) == true)
                {
                    MessageBox.Show("Usuário cadastrado com sucesso!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
        }

        
        // BOTÃO LIMPAR SELEÇÃO
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtUsername.Enabled = true;
            txtUsername.Clear();
            txtIdade.Clear();
            txtEmail.Clear();
            txtSenha.Clear();
            txtAlterego.Clear();
            txtTree.Clear();
            cmbPlano.SelectedIndex = -1;
            chkAtivo.Checked = true;
            txtRegistro.Clear();
            cmbTipoRegistro.SelectedIndex = 0;
            txtUsername.Focus();
        }

     
        // EVENTO: Selecionar tipo de plano (Free ou Network) 
        private void cmbPlano_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Mostra ou esconde campos conforme o tipo de plano (0 - Free, 1 - Network)
            if (cmbPlano.SelectedIndex == 1)
            {
                lblRegistro.Enabled = true;
                lblTipoConta.Enabled = true;
                txtRegistro.Enabled = true;
                cmbTipoRegistro.Enabled = true;
            }
            else
            {
                lblRegistro.Enabled = false;
                lblTipoConta.Enabled = false;
                txtRegistro.Enabled = false;
                cmbTipoRegistro.Enabled = false;
            }
        }

        
        // EVENTO: Pressionar Enter no txtUsername p/ consultar usuário existente
        private void txtUsername_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;

                try
                {
                    DAO_Conexao.con.Open();

                    // Busca o usuário no banco
                    MySqlCommand cmdUser = new MySqlCommand("SELECT * FROM AretiVitae_Usuario WHERE username='" + txtUsername.Text.Trim() + "';", DAO_Conexao.con);
                    using (MySqlDataReader resultado = cmdUser.ExecuteReader()) //Uso de using para tratar posteriores erros de abertura de conexões com o banco de dados
                    {
                        if (resultado.Read())
                        {
                            // Preenche os campos com as informações do usuário
                            txtUsername.Text = resultado["username"].ToString();
                            txtIdade.Text = resultado["idade"].ToString();
                            txtEmail.Text = resultado["email"].ToString();
                            txtSenha.Text = resultado["senha"].ToString();
                            txtAlterego.Text = resultado["alter_ego"].ToString();
                            txtTree.Text = resultado["tree"].ToString();
                            cmbPlano.SelectedIndex = int.Parse(resultado["assinatura"].ToString());

                            // Define se o usuário está ativo
                            int ativo = int.Parse(resultado["ativo"].ToString());
                            chkAtivo.Checked = (ativo == 0);

                            txtUsername.Enabled = false;
                            btnAtualizar.Focus();

                            // Se o plano for Free, esconde os campos extras
                            if (cmbPlano.SelectedIndex == 0)
                            {
                                lblTipoConta.Enabled = false;
                                lblRegistro.Enabled = false;
                                cmbTipoRegistro.Enabled = false;
                                txtRegistro.Enabled = false;
                            }
                            else // Se for Premium, mostra e preenche
                            {
                                string tipoRegistro = resultado["assinatura"].ToString();
                                if (tipoRegistro == "Pessoa Física")
                                {
                                    cmbTipoRegistro.SelectedIndex = 0;
                                }
                                else if (tipoRegistro == "Pessoa Jurídica")
                                {
                                    cmbTipoRegistro.SelectedIndex = 1;
                                }

                                string registro = resultado["registro"].ToString();
                                txtRegistro.Text = registro;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Usuário não encontrado!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao consultar: " + ex.Message);
                }
                finally
                {
                    if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                        DAO_Conexao.con.Close();
                }
            }
        }


        // EVENTO: Troca de tipo de registro
        private void cmbTipoRegistro_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Troca o texto do label de acordo com o tipo
            if (cmbTipoRegistro.SelectedIndex == 0)
                lblRegistro.Text = "CPF";
            else
                lblRegistro.Text = "CNPJ";

            lblRegistro.Visible = true;
            txtRegistro.Visible = true;
        }

        
        // BOTÃO LISTAR USUÁRIOS - abertura de flistaUsuarios
        private void btnListarUsuarios_Click(object sender, EventArgs e)
        {
            flistaUsuarios listaUsuarios = new flistaUsuarios();
            listaUsuarios.Show();
        }

        private void cadUsuario_Load(object sender, EventArgs e)
        {
            // Evento de carregamento do formulário (vazio)
        }
    }
}
