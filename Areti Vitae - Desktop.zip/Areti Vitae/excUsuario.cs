﻿using MySql.Data.MySqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

//TELA DE EXCLUSÃO (DESATIVAÇÃO) DE USUÁRIOS
namespace Tela_Admin
{
    public partial class excUsuario : Form
    {
        public excUsuario()
        {
            InitializeComponent();

            // === Estilização de Background ===
            BackColor = Color.FromArgb(12, 27, 60);

            // === Estilização dos componentes do formulário ===
            grpUsuario.ForeColor = Color.White;
            lblUsername.ForeColor = Color.White;
            lblEmail.ForeColor = Color.White;
            lblSenha.ForeColor = Color.White;

            // === Estilização dos botões ===
            btnExcluir.BackColor = Color.FromArgb(130, 151, 217);
            btnExcluir.ForeColor = Color.FromArgb(12, 27, 60);

            btnListarUsuarios.BackColor = Color.FromArgb(130, 151, 217);
            btnListarUsuarios.ForeColor = Color.FromArgb(12, 27, 60);
        }

        // BOTÃO EXCLUIR USUÁRIO
        private void button1_Click(object sender, EventArgs e)
        {
            // Atribuição dos valores dos campos às variáveis locais
            string username = txtUsername.Text;
            string email = txtEmail.Text;
            string senha = txtSenha.Text;

            try
            {
                Usuario usuario = new Usuario();

                // Chama o método excluirUsuario da classe Usuario
                if (usuario.excluirUsuario(username, email, senha) == true)
                {
                    MessageBox.Show("Usuário excluído com sucesso!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Erro ao excluir usuário!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }

        
        private void excUsuario_Load(object sender, EventArgs e)
        {
            
        }

        // EVENTO: Pressionar Enter no campo txtUsername para consultar usuário existente
        private void txtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true; //Evitar a quebra de linha ao pressionar ENTER

                try
                {
                    Usuario usuario = new Usuario();
                    MySqlDataReader resultado = usuario.consultarUsuario(txtUsername.Text.Trim());

                    // Se encontrar o usuário, preenche os campos com os dados retornados
                    if (resultado.Read())
                    {
                        txtUsername.Text = resultado["username"].ToString();
                        txtEmail.Text = resultado["email"].ToString();
                        txtSenha.Text = resultado["senha"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Usuário não encontrado!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    resultado.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao consultar usuário: " + ex.Message);
                    Console.WriteLine(ex.ToString());
                }
                finally
                {
                    // Fecha a conexão se estiver aberta
                    DAO_Conexao.con.Close();
                }
            }
        }

        // BOTÃO LISTAR USUÁRIOS
        private void btnListarUsuarios_Click(object sender, EventArgs e)
        {
            // Abre o formulário de listagem de usuários
            flistaUsuarios listarUsuarios = new flistaUsuarios();
            listarUsuarios.ShowDialog();
        }

        // BOTÃO LIMPAR CAMPOS
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            // Limpar todos os campos e ênfase no txtUsername
            txtUsername.Clear();
            txtUsername.Focus();

            txtEmail.Clear();
            txtSenha.Clear();
        }
    }
}
