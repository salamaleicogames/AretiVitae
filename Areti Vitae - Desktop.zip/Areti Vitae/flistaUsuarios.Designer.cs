﻿namespace Tela_Admin
{
    partial class flistaUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(flistaUsuarios));
            this.dgwUsuarios = new System.Windows.Forms.DataGridView();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.lblLegAssinatura = new System.Windows.Forms.Label();
            this.lblLegAtivo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgwUsuarios)).BeginInit();
            this.SuspendLayout();
            // 
            // dgwUsuarios
            // 
            this.dgwUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwUsuarios.Location = new System.Drawing.Point(28, 128);
            this.dgwUsuarios.Name = "dgwUsuarios";
            this.dgwUsuarios.Size = new System.Drawing.Size(749, 310);
            this.dgwUsuarios.TabIndex = 1;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Josefin Sans", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(262, 9);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(317, 45);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "Areti Vitae - Usuários";
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Josefin Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(388, 54);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(72, 24);
            this.lblLegenda.TabIndex = 3;
            this.lblLegenda.Text = "Legenda";
            // 
            // lblLegAssinatura
            // 
            this.lblLegAssinatura.AutoSize = true;
            this.lblLegAssinatura.Font = new System.Drawing.Font("Josefin Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegAssinatura.Location = new System.Drawing.Point(285, 78);
            this.lblLegAssinatura.Name = "lblLegAssinatura";
            this.lblLegAssinatura.Size = new System.Drawing.Size(280, 20);
            this.lblLegAssinatura.TabIndex = 4;
            this.lblLegAssinatura.Text = "Assinatura: 0 - Plano Free;   1 - Plano Network";
            // 
            // lblLegAtivo
            // 
            this.lblLegAtivo.AutoSize = true;
            this.lblLegAtivo.Font = new System.Drawing.Font("Josefin Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegAtivo.Location = new System.Drawing.Point(285, 98);
            this.lblLegAtivo.Name = "lblLegAtivo";
            this.lblLegAtivo.Size = new System.Drawing.Size(293, 20);
            this.lblLegAtivo.TabIndex = 5;
            this.lblLegAtivo.Text = "Ativo: 0 - Usuário ativo,   1 - Usuário Desativado";
            // 
            // listaUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblLegAtivo);
            this.Controls.Add(this.lblLegAssinatura);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.dgwUsuarios);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "listaUsuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista de Usuários";
            this.Load += new System.EventHandler(this.listaUsuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwUsuarios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgwUsuarios;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblLegenda;
        private System.Windows.Forms.Label lblLegAssinatura;
        private System.Windows.Forms.Label lblLegAtivo;
    }
}