﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace Tela_Admin
{
    internal class Usuario
    {
        string username;
        int idade;
        string email, senha, alterego, tree;
        int assinatura, ativo;

        public string Username { get => username; set => username = value; }
        public int Idade { get => idade; set => idade = value; }
        public string Email { get => email; set => email = value; }
        public string Senha { get => senha; set => senha = value; }
        public string Alterego { get => alterego; set => alterego = value; }
        public string Tree { get => tree; set => tree = value; }
        public int Assinatura { get => assinatura; set => assinatura = value; }
        public int Ativo { get => ativo; set => ativo = value; }

        public Usuario(string username, int idade, string email, string senha, string alterego, string tree, int assinatura)
        {
            this.username = username;
            this.idade = idade;
            this.email = email;
            this.senha = senha;
            this.alterego = alterego;
            this.tree = tree;
            this.Assinatura = assinatura;
            this.Ativo = 0;
        }

        public Usuario() { }

        // CADASTRAR USUÁRIO
        public bool cadastrarUsuario(string username, int idade, string email, string senha, string alterego, string tree, int assinatura, string tipoRegistro, string registro)
        {
            bool cad = false;
            try
            {
                DAO_Conexao.con.Open();

                MySqlCommand inserir = new MySqlCommand(
                    "INSERT INTO AretiVitae_Usuario (username, idade, email, senha, alter_ego, tree, assinatura, tipoRegistro, registro, ativo) VALUES ('" + username + "', " + idade + ", '" + email + "', '" + senha + "', '" + alterego + "', '" + tree + "', " + assinatura + ",'" +tipoRegistro+ "','" +registro+"', 0);" , DAO_Conexao.con);

                int linhasAfetadas = inserir.ExecuteNonQuery();
                if (linhasAfetadas > 0)
                {
                    cad = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                    DAO_Conexao.con.Close();
            }

            return cad;
        }


        // CONSULTAR USUÁRIO
        public MySqlDataReader consultarUsuario(string username)
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand(
                    "SELECT * FROM AretiVitae_Usuario WHERE username = '" + username + "';",
                    DAO_Conexao.con
                );
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao consultar usuário: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return resultado;
        }

        // ATUALIZAR USUÁRIO
        public bool atualizarUsuario(string username, int idade, string email, string senha, string alterego, string tree, int assinatura, string tipoRegistro, string registro, int ativo)
        {
            bool resultado = false;
            try
            {
                DAO_Conexao.con.Open();

               MySqlCommand atualizar = new MySqlCommand ("UPDATE AretiVitae_Usuario SET idade = " + idade + ", email = '" + email + "', senha = '" + senha + "', alter_ego = '" + alterego + "', tree = '" + tree + "', assinatura = " + assinatura + ", tipoRegistro = '"+tipoRegistro+"', registro = '" +registro+"', ativo = " + ativo + " WHERE username = '" + username + "';", DAO_Conexao.con);
                int linhasAfetadas = atualizar.ExecuteNonQuery(); 
                
                if (linhasAfetadas > 0)
                {
                    resultado = true;
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar usuário: " + ex.Message, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                resultado = false;
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                    DAO_Conexao.con.Close();
            }

            return resultado;
        }

        // --- EXCLUIR/DESATIVAR USUÁRIO ---
        public bool excluirUsuario(string username, string email, string senha)
        {
            bool resultado = false;
            try
            {
                DAO_Conexao.con.Open();

                string query = "UPDATE AretiVitae_Usuario SET ativo = 1 WHERE username = '" + username + "' AND email = '" + email + "' AND senha = '" + senha + "';";
                MySqlCommand atualizar = new MySqlCommand(query, DAO_Conexao.con);
                atualizar.ExecuteNonQuery();
                resultado = true;

                // Se tiver assinatura Network, desativa também
                MySqlCommand cmdId = new MySqlCommand("SELECT id FROM AretiVitae_Usuario WHERE username = '" + username + "';", DAO_Conexao.con);
                int idUsuario = int.Parse(cmdId.ExecuteScalar().ToString());

                string queryAssinatura = "UPDATE AretiVitae_Assinatura SET ativo = 1 WHERE id_usuario = " + idUsuario + ";";
                MySqlCommand atualizarAssinatura = new MySqlCommand(queryAssinatura, DAO_Conexao.con);
                atualizarAssinatura.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir usuário: " + ex.Message);
                resultado = false;
            }
            finally
            {
                if (DAO_Conexao.con.State == System.Data.ConnectionState.Open)
                    DAO_Conexao.con.Close();
            }

            return resultado;
        }
    
        //CONSULTAR ADMINISTRADOR
        public MySqlDataReader consultarUsuarioADM()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand("SELECT * FROM AretiVitae_Admin;", DAO_Conexao.con);
                resultado = consultar.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return resultado;
        }

        //ATUALIZAR ADMINISTRADOR
        public bool atualizarUsuarioADM(string usuario, string senha)
        {
            bool resultado = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualizar = new MySqlCommand("UPDATE AretiVitae_Admin SET senha = '" + senha + "' WHERE usuario = '" + usuario + "';", DAO_Conexao.con);
                int linhas = atualizar.ExecuteNonQuery();
                resultado = linhas > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                resultado = false;
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return resultado;
        }

        //CONSULTAR SENHA ADMINISTRADOR
        public string consultarSenhaADM(string usuario)
        {
            string senha = "";
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consultar = new MySqlCommand(
                    "SELECT senha FROM AretiVitae_Admin WHERE usuario = '" + usuario + "';",
                    DAO_Conexao.con
                );
                MySqlDataReader r = consultar.ExecuteReader();
                if (r.Read())
                {
                    senha = r["senha"].ToString();
                }
                r.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return senha;
        }

    }
}
