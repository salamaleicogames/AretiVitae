﻿namespace Tela_Admin
{
    partial class fAlterarSenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fAlterarSenha));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.cmbUsuario = new System.Windows.Forms.ComboBox();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.txtNovaSenha = new System.Windows.Forms.TextBox();
            this.lblNovaSenha = new System.Windows.Forms.Label();
            this.lblConfNSenha = new System.Windows.Forms.Label();
            this.txtConfirmarNSenha = new System.Windows.Forms.TextBox();
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.imgLogo = new System.Windows.Forms.PictureBox();
            this.txtdDescricao = new System.Windows.Forms.Label();
            this.backgroundSecond = new System.Windows.Forms.PictureBox();
            this.lblSenhaAtual = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundSecond)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Josefin Sans", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(366, 23);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(411, 43);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Alterar Senha - Administrador";
            // 
            // cmbUsuario
            // 
            this.cmbUsuario.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUsuario.FormattingEnabled = true;
            this.cmbUsuario.Location = new System.Drawing.Point(586, 92);
            this.cmbUsuario.Name = "cmbUsuario";
            this.cmbUsuario.Size = new System.Drawing.Size(164, 33);
            this.cmbUsuario.TabIndex = 1;
            this.cmbUsuario.SelectedIndexChanged += new System.EventHandler(this.cmbUsuario_SelectedIndexChanged);
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(352, 92);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(205, 25);
            this.lblUsuario.TabIndex = 2;
            this.lblUsuario.Text = "Selecione o administrador: ";
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenha.Location = new System.Drawing.Point(449, 140);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(103, 25);
            this.lblSenha.TabIndex = 3;
            this.lblSenha.Text = "Senha Atual:";
            // 
            // txtNovaSenha
            // 
            this.txtNovaSenha.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNovaSenha.Location = new System.Drawing.Point(586, 220);
            this.txtNovaSenha.Multiline = true;
            this.txtNovaSenha.Name = "txtNovaSenha";
            this.txtNovaSenha.Size = new System.Drawing.Size(164, 36);
            this.txtNovaSenha.TabIndex = 5;
            // 
            // lblNovaSenha
            // 
            this.lblNovaSenha.AutoSize = true;
            this.lblNovaSenha.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNovaSenha.Location = new System.Drawing.Point(449, 223);
            this.lblNovaSenha.Name = "lblNovaSenha";
            this.lblNovaSenha.Size = new System.Drawing.Size(108, 25);
            this.lblNovaSenha.TabIndex = 6;
            this.lblNovaSenha.Text = "Nova Senha: ";
            // 
            // lblConfNSenha
            // 
            this.lblConfNSenha.AutoSize = true;
            this.lblConfNSenha.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfNSenha.Location = new System.Drawing.Point(372, 276);
            this.lblConfNSenha.Name = "lblConfNSenha";
            this.lblConfNSenha.Size = new System.Drawing.Size(185, 25);
            this.lblConfNSenha.TabIndex = 8;
            this.lblConfNSenha.Text = "Confirmar Nova Senha: ";
            // 
            // txtConfirmarNSenha
            // 
            this.txtConfirmarNSenha.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmarNSenha.Location = new System.Drawing.Point(586, 273);
            this.txtConfirmarNSenha.Multiline = true;
            this.txtConfirmarNSenha.Name = "txtConfirmarNSenha";
            this.txtConfirmarNSenha.Size = new System.Drawing.Size(164, 36);
            this.txtConfirmarNSenha.TabIndex = 7;
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.Font = new System.Drawing.Font("Josefin Sans", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmar.Location = new System.Drawing.Point(374, 328);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(376, 46);
            this.btnConfirmar.TabIndex = 9;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = true;
            this.btnConfirmar.Click += new System.EventHandler(this.btnAlterarSenha_Click);
            // 
            // imgLogo
            // 
            this.imgLogo.Image = ((System.Drawing.Image)(resources.GetObject("imgLogo.Image")));
            this.imgLogo.Location = new System.Drawing.Point(33, 66);
            this.imgLogo.Name = "imgLogo";
            this.imgLogo.Size = new System.Drawing.Size(248, 281);
            this.imgLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgLogo.TabIndex = 12;
            this.imgLogo.TabStop = false;
            // 
            // txtdDescricao
            // 
            this.txtdDescricao.AutoSize = true;
            this.txtdDescricao.BackColor = System.Drawing.Color.Transparent;
            this.txtdDescricao.Font = new System.Drawing.Font("Josefin Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdDescricao.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtdDescricao.Location = new System.Drawing.Point(8, 407);
            this.txtdDescricao.Name = "txtdDescricao";
            this.txtdDescricao.Size = new System.Drawing.Size(192, 30);
            this.txtdDescricao.TabIndex = 11;
            this.txtdDescricao.Text = "Developer Aplication";
            // 
            // backgroundSecond
            // 
            this.backgroundSecond.BackColor = System.Drawing.Color.Snow;
            this.backgroundSecond.Location = new System.Drawing.Point(-2, -1);
            this.backgroundSecond.Name = "backgroundSecond";
            this.backgroundSecond.Size = new System.Drawing.Size(345, 477);
            this.backgroundSecond.TabIndex = 10;
            this.backgroundSecond.TabStop = false;
            // 
            // lblSenhaAtual
            // 
            this.lblSenhaAtual.AutoSize = true;
            this.lblSenhaAtual.Font = new System.Drawing.Font("Josefin Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenhaAtual.Location = new System.Drawing.Point(590, 140);
            this.lblSenhaAtual.Name = "lblSenhaAtual";
            this.lblSenhaAtual.Size = new System.Drawing.Size(0, 25);
            this.lblSenhaAtual.TabIndex = 13;
            // 
            // fAlterarSenha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblSenhaAtual);
            this.Controls.Add(this.imgLogo);
            this.Controls.Add(this.txtdDescricao);
            this.Controls.Add(this.backgroundSecond);
            this.Controls.Add(this.btnConfirmar);
            this.Controls.Add(this.lblConfNSenha);
            this.Controls.Add(this.txtConfirmarNSenha);
            this.Controls.Add(this.lblNovaSenha);
            this.Controls.Add(this.txtNovaSenha);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.cmbUsuario);
            this.Controls.Add(this.lblTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fAlterarSenha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Alterar Senha - ADM";
            this.Load += new System.EventHandler(this.fAlterarSenha_Load);
            ((System.ComponentModel.ISupportInitialize)(this.imgLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.backgroundSecond)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.ComboBox cmbUsuario;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.TextBox txtNovaSenha;
        private System.Windows.Forms.Label lblNovaSenha;
        private System.Windows.Forms.Label lblConfNSenha;
        private System.Windows.Forms.TextBox txtConfirmarNSenha;
        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.PictureBox imgLogo;
        private System.Windows.Forms.Label txtdDescricao;
        private System.Windows.Forms.PictureBox backgroundSecond;
        private System.Windows.Forms.Label lblSenhaAtual;
    }
}