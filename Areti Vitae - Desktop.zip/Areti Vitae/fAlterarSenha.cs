﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//TELA DE REFATORAÇÃO DE SENHA DE USUÁRIO ADMINISTRADOR - RESTRITO A 'ADM MASTER'
namespace Tela_Admin
{
    public partial class fAlterarSenha : Form
    {
        public fAlterarSenha()
        {
            InitializeComponent();
         
            //Estilização dos Botões
            btnConfirmar.FlatStyle = FlatStyle.Flat;
            btnConfirmar.FlatAppearance.BorderColor = System.Drawing.Color.Gray;

            //Estilização dos componentes 
            txtdDescricao.BackColor = System.Drawing.Color.FromArgb(12, 27, 60);
            backgroundSecond.BackColor = System.Drawing.Color.FromArgb(12, 27, 60);
            imgLogo.BackColor = System.Drawing.Color.FromArgb(12, 27, 60);

            //Carregamento dos usuários ADM no comboBox
            Usuario user = new Usuario();
            MySqlDataReader r = user.consultarUsuarioADM();
            while (r.Read())
                cmbUsuario.Items.Add(r["usuario"].ToString());
            DAO_Conexao.con.Close();
        }

        //BOTÃO ALTERAR SENHA
        private void btnAlterarSenha_Click(object sender, EventArgs e)
        {
            string usuario = cmbUsuario.Text;
            string senha = txtConfirmarNSenha.Text;

            try
            {
                // Verifica se os campos estão vazios
                if (txtNovaSenha.Text == "" || txtConfirmarNSenha.Text == "" || cmbUsuario.Text == "" || lblSenhaAtual.Text == "")
                {
                    MessageBox.Show("Preencha os campos vazios!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (txtNovaSenha.Text != txtConfirmarNSenha.Text)
                {
                    MessageBox.Show("Confirme a nova senha corretamente!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    //Criação de objeto Usuário p/ chamada de método 'atualizarUsuario'
                    Usuario user = new Usuario();
                    if (user.atualizarUsuarioADM(usuario, senha))
                    {
                        MessageBox.Show("Senha alterada com sucesso!");
                    }
                    else
                    {
                        MessageBox.Show("Não foi possível alterar a senha!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void fAlterarSenha_Load(object sender, EventArgs e)
        {

        }


        //Evento: Selecionar Usuário e imprimir sua respectiva senha
        private void cmbUsuario_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbUsuario.SelectedItem != null) // Verifica se algo foi selecionado
            {
                string usuarioSelecionado = cmbUsuario.SelectedItem.ToString();

                Usuario user = new Usuario();
                lblSenhaAtual.Text = user.consultarSenhaADM(usuarioSelecionado); // Busca a senha e mostra na TextBox
            }

        }

    }
}
