﻿namespace Tela_Admin
{
    partial class listaUsuariosADM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(listaUsuariosADM));
            this.lblLegAssinatura = new System.Windows.Forms.Label();
            this.lblLegenda = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.dgwUsuariosADM = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgwUsuariosADM)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLegAssinatura
            // 
            this.lblLegAssinatura.AutoSize = true;
            this.lblLegAssinatura.Font = new System.Drawing.Font("Josefin Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegAssinatura.Location = new System.Drawing.Point(276, 78);
            this.lblLegAssinatura.Name = "lblLegAssinatura";
            this.lblLegAssinatura.Size = new System.Drawing.Size(199, 20);
            this.lblLegAssinatura.TabIndex = 8;
            this.lblLegAssinatura.Text = "Tipo: 1 - ADM;   2 - ADM Master";
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Josefin Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(340, 54);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(72, 24);
            this.lblLegenda.TabIndex = 7;
            this.lblLegenda.Text = "Legenda";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Josefin Sans", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(175, 9);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(423, 45);
            this.lblTitulo.TabIndex = 6;
            this.lblTitulo.Text = "Areti Vitae - Administradores";
            // 
            // dgwUsuariosADM
            // 
            this.dgwUsuariosADM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwUsuariosADM.Location = new System.Drawing.Point(24, 115);
            this.dgwUsuariosADM.Name = "dgwUsuariosADM";
            this.dgwUsuariosADM.Size = new System.Drawing.Size(699, 302);
            this.dgwUsuariosADM.TabIndex = 9;
            // 
            // listaUsuariosADM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(749, 434);
            this.Controls.Add(this.dgwUsuariosADM);
            this.Controls.Add(this.lblLegAssinatura);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.lblTitulo);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "listaUsuariosADM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lista de Administradores";
            this.Load += new System.EventHandler(this.listaUsuariosADM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwUsuariosADM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblLegAssinatura;
        private System.Windows.Forms.Label lblLegenda;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.DataGridView dgwUsuariosADM;
    }
}