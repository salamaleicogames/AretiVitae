﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//TELA DE GERENCIAMENTO DE USUÁRIOS ADMINISTRADORES (RESTRITO A ADM MASTER)
namespace Tela_Admin
{
    public partial class listaUsuariosADM : Form
    {
        public listaUsuariosADM()
        {
            InitializeComponent();
        }

     
        private void listaUsuariosADM_Load(object sender, EventArgs e)
        {
            //Chamada de método de carregamento da Lista de Usuários Administradores
            carregarUsuarios();

            //Estilização de Background
            BackColor = System.Drawing.Color.FromArgb(12, 27, 60);

            //Estilização de Componentes
            lblTitulo.ForeColor = System.Drawing.Color.White;
            lblLegenda.ForeColor = System.Drawing.Color.White;
            lblLegAssinatura.ForeColor = System.Drawing.Color.Wheat;
        }

        //Método de carregamento da Lista de Usuários Administradores
        private void carregarUsuarios()
        {
            try
            {
                // Abertura de Conexão com o BD
                if (DAO_Conexao.con.State != System.Data.ConnectionState.Open)
                {
                    DAO_Conexao.con.Open();
                }

                string query = "SELECT * FROM AretiVitae_Admin"; // Query de busca no Banco de Dados
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, DAO_Conexao.con);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                dgwUsuariosADM.DataSource = dt; // Preenchimento do DataGridView


                //Renomeando títulos das colunas
                dgwUsuariosADM.Columns["id"].HeaderText = "ID";
                dgwUsuariosADM.Columns["usuario"].HeaderText = "Usuário";
                dgwUsuariosADM.Columns["senha"].HeaderText = "Senha";
                dgwUsuariosADM.Columns["tipo"].HeaderText = "Tipo";

                //Estilização das colunas do DataGridView
                dgwUsuariosADM.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgwUsuariosADM.ColumnHeadersDefaultCellStyle.Font = new Font("Josefin Sans", 10, FontStyle.Bold);
                dgwUsuariosADM.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(130, 151, 217);
                dgwUsuariosADM.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                dgwUsuariosADM.EnableHeadersVisualStyles = false;
                dgwUsuariosADM.DefaultCellStyle.BackColor = Color.White;
                dgwUsuariosADM.DefaultCellStyle.ForeColor = Color.Black;
                dgwUsuariosADM.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(230, 235, 250);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar usuários: " + ex.Message);
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
        }
    }
}
