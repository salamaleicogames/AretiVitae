﻿namespace Tela_Admin
{
    partial class fGerenciarAssinatura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.dgwAssinatura = new System.Windows.Forms.DataGridView();
            this.lblLegAtivo = new System.Windows.Forms.Label();
            this.lblLegenda = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgwAssinatura)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Josefin Sans", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(195, 9);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(401, 45);
            this.lblTitulo.TabIndex = 6;
            this.lblTitulo.Text = "Areti Vitae - Plano Network";
            // 
            // dgwAssinatura
            // 
            this.dgwAssinatura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwAssinatura.Location = new System.Drawing.Point(72, 117);
            this.dgwAssinatura.Name = "dgwAssinatura";
            this.dgwAssinatura.Size = new System.Drawing.Size(624, 321);
            this.dgwAssinatura.TabIndex = 7;
            // 
            // lblLegAtivo
            // 
            this.lblLegAtivo.AutoSize = true;
            this.lblLegAtivo.Font = new System.Drawing.Font("Josefin Sans SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegAtivo.Location = new System.Drawing.Point(246, 77);
            this.lblLegAtivo.Name = "lblLegAtivo";
            this.lblLegAtivo.Size = new System.Drawing.Size(293, 20);
            this.lblLegAtivo.TabIndex = 9;
            this.lblLegAtivo.Text = "Ativo: 0 - Usuário ativo,   1 - Usuário Desativado";
            // 
            // lblLegenda
            // 
            this.lblLegenda.AutoSize = true;
            this.lblLegenda.Font = new System.Drawing.Font("Josefin Sans", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLegenda.Location = new System.Drawing.Point(342, 53);
            this.lblLegenda.Name = "lblLegenda";
            this.lblLegenda.Size = new System.Drawing.Size(72, 24);
            this.lblLegenda.TabIndex = 8;
            this.lblLegenda.Text = "Legenda";
            // 
            // fGerenciarAssinatura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblLegAtivo);
            this.Controls.Add(this.lblLegenda);
            this.Controls.Add(this.dgwAssinatura);
            this.Controls.Add(this.lblTitulo);
            this.Name = "fGerenciarAssinatura";
            this.Text = "Gerenciar Assinaturas";
            this.Load += new System.EventHandler(this.fGerenciarAssinatura_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwAssinatura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.DataGridView dgwAssinatura;
        private System.Windows.Forms.Label lblLegAtivo;
        private System.Windows.Forms.Label lblLegenda;
    }
}