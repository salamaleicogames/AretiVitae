﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tela_Admin
{
    public partial class fRedefinirSenha : Form
    {
        public fRedefinirSenha()
        {
            InitializeComponent();
            txtUsuario.Focus();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void fRedefinirSenha_Load(object sender, EventArgs e)
        {

        }

        private void btnAlterarSenha_Click(object sender, EventArgs e)
        {
            if (txtSenha.Text != txtConfSenha.Text)
            {
                MessageBox.Show("A senha deve ser a mesma em ambos os campos: 'Senha' e 'Confirmar Senha'");
            }

            if (txtUsuario.Text == null || txtUsuario.Text == "" || txtSenha.Text == null || txtSenha.Text == "" || txtConfSenha.Text == null || txtConfSenha.Text == "")
            {
                MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
    }
}
