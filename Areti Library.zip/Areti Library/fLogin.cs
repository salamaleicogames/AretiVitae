﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace Tela_Admin
{
    public partial class fLogin : Form
    {
        public fLogin()
        {
            InitializeComponent();
            txtUsuario.Focus();

            if (DAO_Conexao.getConexao("143.106.241.4", "cl204177", "cl204177", "cl*04062009"))
                Console.WriteLine("Conectado");
            else
                Console.WriteLine("Erro de conexão");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fLogincs_Load(object sender, EventArgs e)
        {
            
        }

        private void linkEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            fRedefinirSenha formRed = new fRedefinirSenha();
            formRed.Show();
        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            //Verificação de campos vazios ou nulos (ignorando espaços em branco)//

            if (string.IsNullOrEmpty(txtUsuario.Text) || string.IsNullOrEmpty(mtxtSenha.Text))
            {
                MessageBox.Show("Preencha todos os campos corretamente!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


            // Validação de Usuário e Senha//
            int tipo = DAO_Conexao.validaLogin(txtUsuario.Text, mtxtSenha.Text);

            if (tipo == 0)
            {
                MessageBox.Show("Usuário/Senha inválidos!");

                DAO_Conexao.con.Close();
            }
            else if (tipo == 1) 
            {
            
                MessageBox.Show("Usuário ADM", "Bem-vindo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Abertura de ´fIndex' e fechar 'fLogin'
                fIndex index = new fIndex(tipo);
                index.Show();
                this.Hide();

            

                DAO_Conexao.con.Close();
            }
            else if (tipo == 2)
            {

                MessageBox.Show("Usuário ADM Master", "Bem-vindo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                //Abertura de ´fIndex' e fechar 'fLogin'
                fIndex index = new fIndex(tipo);
                index.Show();
                this.Hide();

                DAO_Conexao.con.Close();
            }
        }


    }
}
