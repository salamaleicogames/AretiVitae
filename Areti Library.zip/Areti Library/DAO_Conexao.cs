﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tela_Admin
{
    internal class DAO_Conexao
    {
        public static MySqlConnection con;
        public static Boolean getConexao(String local, String banco, String user, String senha)
        {
            Boolean retorno = false;
            try
            {
                con = new MySqlConnection("Server=" + local + ";User ID=" + user + ";" + "database=" + banco + "; password=" + senha + "; SslMode = none");
                //con.Open();
                retorno = true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return retorno;
        }


        public static int validaLogin(string usuario, string senha)
        {
            int log = 0; // 0 = inválido, 1 = ADM, 2 = ADM Master
            try
            {
                con.Open();

                MySqlCommand login = new MySqlCommand("SELECT tipo FROM AretiLibrary_Admin WHERE usuario = '" + usuario + "' AND senha = '" + senha + "';", DAO_Conexao.con);
                Console.WriteLine(login.CommandText);

                MySqlDataReader resultado = login.ExecuteReader();

                if (resultado.Read())
                {
                    log = Convert.ToInt32(resultado["tipo"]);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao validar login: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
            return log;
        }

    }
}
